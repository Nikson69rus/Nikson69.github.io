---
layout: post
title:  "Добро пожаловать"
date:   2015-02-10 22:37:00
categories: site
tags:
- site
---
Первая страница блога. 

Поделюсь некоторыми ссылками которые у меня были на сайтике.

<table>
    <tbody>
        <tr>
            <td>
                Ссылка
            </td>
            <td>
                Описание
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//www.spiritstones.info/">
                    spiritstones.info
                </a>
            </td>
            <td>
                Гайды по игре на мобилку/
                <a target="_blank" href="//spiritstoneswiki.com/index.php?title=Hell_Raider#">
                    Лучник
                </a>
                ,                					
                <a target="_blank" href="//spiritstoneswiki.com/index.php?title=Pyromancer">
                    Маг
                </a>
                ,<a target="_blank" href="//spiritstoneswiki.com/index.php?title=Demon_Blader#">
                    Рога
                </a>
              <!--  <a href="/links/1.jpg">
                    пикча
                </a>-->
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//g.zeos.in/">
                    g.zeos.in
                </a>
            </td>
            <td>
                Гугл поищит за тебя, прикольная штука =)
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//goo.gl">
                    goo.gl
                </a>
            </td>
            <td>
                Делает короткие ссылки, очень удобно
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//rupier.com/forum/">
                    rupier.com
                </a>
            </td>
            <td>
                Тульский торрент трейкер.
            </td>
        </tr>
      <!--  <tr>
            <td>
                <a target="_blank" href="//skotobaza.org/">
                    skotobaza.org
                </a>
            </td>
            <td>
                Приватные фото вк // посмотри что нашел, любопытный, хитрец! 
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//poiskvk.ru/">
                    poiskvk.ru
                </a>
            </td>
            <td>
                Приватные фото вк
            </td>
        </tr> -->
        <tr>
            <td>
                <a target="_blank" href="//tenshi.ru/">
                    tenshi.ru
                </a>
            </td>
            <td>
                Anime-ost
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//www.ptsecurity.ru/lab/webinars/#">
                    ptsecurity.ru
                </a>
            </td>
            <td>
                Вебинары по безопасности
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//denis.evsyukov.org/">
                    denis.evsyukov.org
                </a>
            </td>
            <td>
                Интересный блог
            </td>
        </tr>
        <tr>
            <td>
                <a target="_blank" href="//klen.github.io/">
                    klen.github.io
                </a>
            </td>
            <td>
                Еще одни блог
            </td>
        </tr>
    </tbody>
</table>